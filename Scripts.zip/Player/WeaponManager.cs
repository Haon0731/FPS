using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Netcode;

public class WeaponManager : NetworkBehaviour
{
    [SerializeField]
    private PlayerWeapon primaryWeapon;
    [SerializeField]
    private PlayerWeapon secondaryWeapon;

    private NetworkVariable<int> currentWeaponIndex = new NetworkVariable<int>();   // ��¼��ҵ�ǰ�ֵ�ǹ����ʼֵΪ0

    [SerializeField]
    private GameObject weaponHolder;

    private PlayerWeapon currentWeapon;

    private WeaponGraphics currentWeaponGraphics;

    private AudioSource currentWeaponAudioSource;

    public override void OnNetworkSpawn()
    {
        base.OnNetworkSpawn();
        EquipWeapon(currentWeaponIndex.Value);
    }

    public void EquipWeapon(int weaponIndex)
    {
        if (weaponIndex == 0)
        {
            currentWeapon = primaryWeapon;
        }
        else if (weaponIndex == 1)
        {
            currentWeapon = secondaryWeapon;
        }

        if (weaponHolder.transform.childCount > 0)
        {
            Destroy(weaponHolder.transform.GetChild(0).gameObject); // ȥ����ǰ���ص�ǹ��gameObject
        }
        // ������Ⱦһ�������������
        GameObject weaponObject = Instantiate(currentWeapon.graphics, weaponHolder.transform.position, weaponHolder.transform.rotation);
        weaponObject.transform.SetParent(weaponHolder.transform);   // ������������ص�WeaponHolder��

        currentWeaponGraphics = weaponObject.GetComponent<WeaponGraphics>();
        currentWeaponAudioSource = weaponObject.GetComponent<AudioSource>();
        if (IsLocalPlayer)
        {
            currentWeaponAudioSource.spatialBlend = 0f; // ������ҿ�ǹʱ��ǹ����Ϊ2D
        }
    }

    public PlayerWeapon GetCurrentWeapon()
    {
        return currentWeapon;
    }

    public WeaponGraphics GetCurrentWeaponGraphics()
    {
        return currentWeaponGraphics;
    }

    public AudioSource GetCurrentWeaponAudioSource()
    {
        return currentWeaponAudioSource;
    }

    private void ToggleWeapon(int weaponIndex)
    {
        EquipWeapon(weaponIndex);
    }

    [ClientRpc]
    private void ToggleWeaponClientRpc(int weaponIndex)
    {
        ToggleWeapon(weaponIndex);
    }

    [ServerRpc]
    private void ToggleWeaponServerRpc()
    {
        currentWeaponIndex.Value = (currentWeaponIndex.Value + 1) % 2;  // �ı���ֵ����ǹ��ֻ������ǹ
        if (!IsHost)
        {
            ToggleWeapon(currentWeaponIndex.Value); // ����һ��Ҫ������ֵ����Ϊ�ͻ��˺ͷ������˵����������ֵ��һ��ͬ�����������ǹ��������⣬��������ֱ�Ӵ��޸ĺõ�ֵ
        }
        ToggleWeaponClientRpc(currentWeaponIndex.Value);    // ͬ��
    }

    public void SetDefaultWeapon()
    {
        currentWeaponIndex.Value = 0;
    }

    // Update is called once per frame
    void Update()
    {
        if (IsLocalPlayer)
        {
            if (Input.GetKeyDown(KeyCode.Q))    // ����Q�л�����
            {
                ToggleWeaponServerRpc();
            }
        }
    }

    public void Reload(PlayerWeapon playerWeapon)
    {
        if (playerWeapon.isReloading) return;
        playerWeapon.isReloading = true;
        StartCoroutine(ReloadCoroutine(playerWeapon));  // �������̻߳���
    }

    private IEnumerator ReloadCoroutine(PlayerWeapon playerWeapon)
    {
        yield return new WaitForSeconds(playerWeapon.reloadTime);

        playerWeapon.bullets = playerWeapon.maxBullets;

        playerWeapon.isReloading = false;
    }
}
