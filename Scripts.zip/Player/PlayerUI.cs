using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class PlayerUI : MonoBehaviour
{
    public static PlayerUI Singleton;   // ����

    private Player player = null;  // �������
    [SerializeField]
    private TextMeshProUGUI bulletsText;    // չʾ��Ϣ
    [SerializeField]
    private GameObject bulletsObject;   // ��ʼΪ����״̬

    private WeaponManager weaponManager;
    [SerializeField]
    private Transform healthBarFill;
    [SerializeField]
    private GameObject healthBarObject;

    private void Awake()
    {
        Singleton = this;
    }

    public void SetPlayer(Player localPlayer)
    {
        player = localPlayer;
        weaponManager = player.GetComponent<WeaponManager>();
        bulletsObject.SetActive(true);  // ����ҽ�����Ϸ�����õ�ҩչʾ
        healthBarObject.SetActive(true);    // ����ҽ�����Ϸ������Ѫ��չʾ
    }

    // Update is called once per frame
    void Update()
    {
        if (player == null) return;

        var currentWeapon = weaponManager.GetCurrentWeapon();
        if (currentWeapon.isReloading)
        {
            bulletsText.text = "Reloading...";

        }
        else
        {
            bulletsText.text = "Bullets: " + currentWeapon.bullets + "/" + currentWeapon.maxBullets;
        }

        healthBarFill.localScale = new Vector3(player.GetHealth() / 100f, 1f, 1f);   // ����Ѫ���ı�Ѫ������
    }
}

 