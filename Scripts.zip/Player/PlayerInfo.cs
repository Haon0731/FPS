using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using TMPro;
using UnityEngine;

public class PlayerInfo : MonoBehaviour
{
    [SerializeField]
    private TextMeshProUGUI playerName; // �û�������
    [SerializeField]
    private Transform infoUI;   // UI��λ����Ϣ
    [SerializeField]
    private Transform playerHealth;

    private Player player;

    private void Start()
    {
        player = GetComponent<Player>();
    }

    // Update is called once per frame
    void Update()
    {
        playerName.text = transform.name;
        playerHealth.localScale = new UnityEngine.Vector3(player.GetHealth() / 100f, 1f, 1f);

        // ����Ϣ����Զ�����Լ�
        var camera = Camera.main;
        infoUI.transform.LookAt(infoUI.transform.position + camera.transform.rotation * UnityEngine.Vector3.back, camera.transform.rotation * UnityEngine.Vector3.up);
        infoUI.Rotate(new UnityEngine.Vector3(0f, 180f, 0f));
    }
}


 