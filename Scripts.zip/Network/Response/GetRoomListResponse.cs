using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class GetRoomListResponse
{
    public string error_message;
    public Room[] rooms;
}