using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class BuildRoomResponse
{
    public string error_message;
    public string name;
    public int port;
}